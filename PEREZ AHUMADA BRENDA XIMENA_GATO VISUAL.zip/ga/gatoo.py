from tkinter import * ##Se crea la ventana
from tkinter import messagebox 
from time import sleep
from tkinter import ttk
import pymysql

##Se conecta con la base de datos
conn=pymysql.connect(host='localhost', user='root', passwd='', db='test')
cursor=conn.cursor()

##Se define la nueva ventana
def  NuevaVentana():
	##Se crea la ventana 2
	ven2=Tk()
	ven2.geometry("550x400")
	ven2.title("nuevo perfil")
	ven2.config(background="dark green")
	## creacion de los campos de texto
	etiqueta1=Label(ven2,text="id_usuario: ",font="timesnewroman 10 bold")
	etiqueta1.place(x=20,y=20)
	etiqueta2=Label(ven2,text="Nombre de usuario: ",font="timesnewroman 10 bold")
	etiqueta2.place(x=20,y=70)
	etiqueta3=Label(ven2,text="Puntos: ",font="timesnewroman 10 bold")
	etiqueta3.place(x=20,y=120)
	## creacion de los campos de ingreso de datos
	etiqueta1=Entry(ven2,font="timesnewroman 16 bold",state=DISABLED)
	etiqueta1.place(x=170,y=20)
	etiqueta2=Entry(ven2,font="timesnewroman 16 bold")
	etiqueta2.place(x=170,y=70)
	etiqueta3=Entry(ven2,font="timesnewroman 16 bold",state=DISABLED)
	etiqueta3.place(x=170,y=120)
	## creacion del boton de registro
	boton1=Button(ven2,text="Registar",font="timesnewroman 16 bold")
	boton1.place(x=20,y=170)

##Se definen las caracteristicas de la ventana principal
ven = Tk()
ven.resizable(1,1)                                                                                  
ven.geometry("520x450")
ven.title("JUEGO DEL GATO")
ven.config(bg="slateblue1")
ven.config(cursor="heart")
##Se definen las variables para el turno y las jugadas
turno=StringVar()
turno.set("bob")
p1=StringVar()
p2=StringVar()
p3=StringVar()
p4=StringVar()
p5=StringVar()
p6=StringVar()
p7=StringVar()
p8=StringVar()
p9=StringVar()
##Se define el valor
p1.set("1")
p2.set("2")
p3.set("3")
p4.set("4")
p5.set("5")
p6.set("6")
p7.set("7")
p8.set("8")                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
p9.set("9")
##Se define la variable del empate y el valor
Empate=StringVar()
Empate.set("9")
num1=StringVar()
num1.set("1")
##Se define la variable del contador y el valor
contador=StringVar()
contador.set("0")
num2=StringVar()
num2.set("1")
##Se define la variable del contador y el valor de este
contador2=StringVar()
contador2.set("0")
num3=StringVar()
num3.set("1")

##Se define la variable de cada imagen
medusa=PhotoImage(file="medusa.png")
fondo=PhotoImage(file="fondo.png")
bob=PhotoImage(file="bob.png")
patricio=PhotoImage(file="patricio.png")
gary=PhotoImage(file="gary.png")
et7=PhotoImage(file="et7.png")
nueva=PhotoImage(file="rem.png")

def valida(): 
	##Se comienzan a colocar las posibles combinaciones para las ganadas
	##Con p1 de manera horizontal
	if p1.get() == p2.get() and p1.get() == p3.get():
		if p1.get()=="bob":
			ganadorbob()
			messagebox.showinfo(message="Gana "+combo1.get(), title="Gana")
			contador.set(int(contador.get())+int(num2.get()))
			cierre()
			activa()
		else:
			ganadorpatricio()
			messagebox.showinfo(message="Gana "+combo2.get(), title="Gana")
			contador2.set(int(contador2.get())+int(num3.get()))
			cierre()
			activa()
	##Con el p4 de manera horizontal
	elif p4.get() == p5.get() and p4.get() == p6.get():
		if p4.get()=="bob":
			ganadorbob()
			messagebox.showinfo(message="Gana "+combo1.get(), title="Gana")
			contador.set(int(contador.get())+int(num2.get()))
			cierre()
			activa()
		else:
			ganadorpatricio()
			messagebox.showinfo(message="Gana "+combo2.get(), title="Gana")
			contador2.set(int(contador2.get())+int(num3.get()))
			cierre()
			activa()
	##Con el p7 de manera horizontal
	elif p7.get() == p8.get() and p7.get() == p9.get():
		if p7.get()=="bob":
			ganadorbob()
			messagebox.showinfo(message="Gana "+combo1.get(), title="Gana")
			contador.set(int(contador.get())+int(num2.get()))
			cierre()
			activa()
		else:
			ganadorpatricio()
			messagebox.showinfo(message="Gana "+combo2.get(), title="Gana")
			contador2.set(int(contador2.get())+int(num3.get()))
			cierre()
			activa()
	##Con el p1 de manera vertical
	elif p1.get() == p4.get() and p1.get() == p7.get():
		if p1.get()=="bob":
			ganadorbob()
			messagebox.showinfo(message="Gana "+combo1.get(), title="Gana")
			contador.set(int(contador.get())+int(num2.get()))
			cierre()
			activa()
		else:
			ganadorpatricio()
			messagebox.showinfo(message="Gana "+combo2.get(), title="Gana")
			contador2.set(int(contador2.get())+int(num3.get()))
			cierre()
			activa()
	##Con el p2 de manera vertical
	elif p2.get() == p5.get() and p2.get() == p8.get():
		if p2.get()=="bob":
			ganadorbob()
			messagebox.showinfo(message="Gana "+combo1.get(), title="Gana")
			contador.set(int(contador.get())+int(num2.get()))
			cierre()
			activa()
		else:
			ganadorpatricio()
			messagebox.showinfo(message="Gana "+combo2.get(), title="Gana")
			contador2.set(int(contador2.get())+int(num3.get()))
			cierre()
			activa()
	##Con el p3 de manera vertical
	elif p3.get() == p6.get() and p3.get() == p9.get():
		if p3.get()=="bob":
			ganadorbob()
			messagebox.showinfo(message="Gana "+combo1.get(), title="Gana")
			contador.set(int(contador.get())+int(num2.get()))
			cierre()
			activa()
		else:
			ganadorpatricio()
			messagebox.showinfo(message="Gana "+combo2.get(), title="Gana")
			contador2.set(int(contador2.get())+int(num3.get()))
			cierre()
			activa()
	##Con el p1 de manera cruzada
	elif p1.get() == p5.get() and p1.get() == p9.get():
		if p1.get()=="bob":
			ganadorbob()
			messagebox.showinfo(message="Gana "+combo1.get(), title="Gana")
			contador.set(int(contador.get())+int(num2.get()))
			cierre()
			activa()
		else:
			ganadorpatricio()
			messagebox.showinfo(message="Gana "+combo2.get(), title="Gana")
			contador2.set(int(contador2.get())+int(num3.get()))
			cierre()
			activa()
	##Con el p3 de manera cruzada
	elif p3.get() == p5.get() and p3.get() == p7.get():
		if p3.get()=="bob":
			ganadorbob()
			messagebox.showinfo(message="Gana "+combo1.get(), title="Gana")
			contador.set(int(contador.get())+int(num2.get()))
			cierre()
			activa()
		else:
			ganadorpatricio()
			messagebox.showinfo(message="Gana "+combo2.get(), title="Gana")
			contador2.set(int(contador2.get())+int(num3.get()))
			cierre()
			activa()
	##Y si no es ninguna de las anteriores combinaciones sera empate
	elif Empate.get()=="0":
		gifempate()
		messagebox.showinfo(message="Han quedado empatados", title="Empate")
		cierre()
		activa()
def cierre():
	##Aqui se hara que todos los botones se desabiliten, que se vuelva a poner la foto del fondo y el color del boton
	boton1.config(state=DISABLED,image=fondo,bg="light cyan")
	boton2.config(state=DISABLED,image=fondo,bg="light cyan")
	boton3.config(state=DISABLED,image=fondo,bg="light cyan")
	boton4.config(state=DISABLED,image=fondo,bg="light cyan")
	boton5.config(state=DISABLED,image=fondo,bg="light cyan")
	boton6.config(state=DISABLED,image=fondo,bg="light cyan")
	boton7.config(state=DISABLED,image=fondo,bg="light cyan")
	boton8.config(state=DISABLED,image=fondo,bg="light cyan")
	boton9.config(state=DISABLED,image=fondo,bg="light cyan")

def desactivar():
	##Aqui se desabilitaran los botenes de reiniciar y el reiniciar marcador para que no se puedan usar mientras se esta jugando
	boton10.config(bg="medium orchid",image=medusa,state=DISABLED)
	boton11.config(bg="medium orchid",image=gary,state=DISABLED)

def activa():
	##Aqui se activaran los botones (de reiniciar y el de reiniciar marcador) para cuando alguien gane
	boton10.config(bg="medium orchid",image=medusa,state=NORMAL)
	boton11.config(bg="medium orchid",image=gary,state=NORMAL)

##Se define la funcion del reiniciar
def reiniciar():
	##Se reinician los botones y las posiciones
	p1.set("1")
	p2.set("2")
	p3.set("3")
	p4.set("4")
	p5.set("5")
	p6.set("6")
	p7.set("7")
	p8.set("8")
	p9.set("9")
	boton1.config(state=NORMAL,image=fondo,bg="light cyan")
	boton2.config(state=NORMAL,image=fondo,bg="light cyan")
	boton3.config(state=NORMAL,image=fondo,bg="light cyan")
	boton4.config(state=NORMAL,image=fondo,bg="light cyan")
	boton5.config(state=NORMAL,image=fondo,bg="light cyan")
	boton6.config(state=NORMAL,image=fondo,bg="light cyan")
	boton7.config(state=NORMAL,image=fondo,bg="light cyan")
	boton8.config(state=NORMAL,image=fondo,bg="light cyan")
	boton9.config(state=NORMAL,image=fondo,bg="light cyan")
	##Se pone el turno
	turno.set("bob")
	##Se vuelve a poner el empate en 9
	Empate.set("9")
	##Se desabilitan los botones de reiniciar y reiniciar marcador
	desactivar()

##Se define la funcion del reiniciar marcador	
def reiniciar_marc():
	##Se reinician los botones y las posiciones
	p1.set("1")
	p2.set("2")
	p3.set("3")
	p4.set("4")
	p5.set("5")
	p6.set("6")
	p7.set("7")
	p8.set("8")
	p9.set("9")
	boton1.config(state=DISABLED,image=fondo,bg="light cyan")
	boton2.config(state=DISABLED,image=fondo,bg="light cyan")
	boton3.config(state=DISABLED,image=fondo,bg="light cyan")
	boton4.config(state=DISABLED,image=fondo,bg="light cyan")
	boton5.config(state=DISABLED,image=fondo,bg="light cyan")
	boton6.config(state=DISABLED,image=fondo,bg="light cyan")
	boton7.config(state=DISABLED,image=fondo,bg="light cyan")
	boton8.config(state=DISABLED,image=fondo,bg="light cyan")
	boton9.config(state=DISABLED,image=fondo,bg="light cyan")
	##Se coloca el turno
	turno.set("bob")
	##Se coloca el empate como 9
	Empate.set("9")
	##Se pone el contador como 0
	contador.set("0")
	num2.set("1")
	contador2.set("0")
	num3.set("1")
	##Se colocan los combo en normal
	combo1.config(state=NORMAL)
	combo2.config(state=NORMAL)
	combo1.set("")
	combo2.set("")
	desactivar()

##Se definen las posiciones1 para que cambie de una imagen a otra	
def posicion1():
	if turno.get()=="bob":
		boton1.config(image=bob,state=DISABLED)
		p1.set("bob")
		turno.set("patricio")
	else:
		turno.set("bob")
		p1.set("patricio")
		boton1.config(image=patricio,state=DISABLED)
	Empate.set(int(Empate.get())-int(num1.get()))
	valida()
def posicion2():
	if turno.get()=="bob":
		boton2.config(image=bob,state=DISABLED)
		p2.set("bob")
		turno.set("patricio")
	else:
		turno.set("bob")
		p2.set("patricio")
		boton2.config(image=patricio,state=DISABLED)
	Empate.set(int(Empate.get())-int(num1.get()))
	valida()
def posicion3():
	if turno.get()=="bob":
		boton3.config(image=bob,state=DISABLED)
		p3.set("bob")
		turno.set("patricio")
	else:
		turno.set("bob")
		p3.set("patricio")
		boton3.config(image=patricio,state=DISABLED)
	Empate.set(int(Empate.get())-int(num1.get()))
	valida()
def posicion4():
	if turno.get()=="bob":
		boton4.config(image=bob,state=DISABLED)
		p4.set("bob")
		turno.set("patricio")
	else:
		turno.set("bob")
		p4.set("patricio")
		boton4.config(image=patricio,state=DISABLED)
	Empate.set(int(Empate.get())-int(num1.get()))
	valida()
def posicion5():
	if turno.get()=="bob":
		boton5.config(image=bob,state=DISABLED)
		p5.set("bob")
		turno.set("patricio")
	else:
		turno.set("bob")
		p5.set("patricio")
		boton5.config(image=patricio,state=DISABLED)
	Empate.set(int(Empate.get())-int(num1.get()))
	valida()
def posicion6():
	if turno.get()=="bob":
		boton6.config(image=bob,state=DISABLED)
		p6.set("bob")
		turno.set("patricio")
	else:
		turno.set("bob")
		p6.set("patricio")
		boton6.config(image=patricio,state=DISABLED)
	Empate.set(int(Empate.get())-int(num1.get()))
	valida()
def posicion7():
	if turno.get()=="bob":
		boton7.config(image=bob,state=DISABLED)
		p7.set("bob")
		turno.set("patricio")
	else:
		turno.set("bob")
		p7.set("patricio")
		boton7.config(image=patricio,state=DISABLED)
	Empate.set(int(Empate.get())-int(num1.get()))
	valida()
def posicion8():
	if turno.get()=="bob":
		boton8.config(image=bob,state=DISABLED)
		p8.set("bob")
		turno.set("patricio")
	else:
		turno.set("bob")
		p8.set("patricio")
		boton8.config(image=patricio,state=DISABLED)
	Empate.set(int(Empate.get())-int(num1.get()))
	valida()
def posicion9():
	if turno.get()=="bob":
		boton9.config(image=bob,state=DISABLED)
		p9.set("bob")
		turno.set("patricio")
	else:
		turno.set("bob")
		p9.set("patricio")
		boton9.config(image=patricio,state=DISABLED)
	Empate.set(int(Empate.get())-int(num1.get()))
	valida()

##Se  define lo que hara cada combx (funcion)
def combx(event):
	##Se va a desabilitar una vez que ya se haya usado
	combo1.config(state=DISABLED)
def combx1(event):
	##Se desabilitan los botones
	combo2.config(state=DISABLED)
	boton1.config(state=NORMAL)
	boton2.config(state=NORMAL)
	boton3.config(state=NORMAL)
	boton4.config(state=NORMAL)
	boton5.config(state=NORMAL)
	boton6.config(state=NORMAL)
	boton7.config(state=NORMAL)
	boton8.config(state=NORMAL)
	boton9.config(state=NORMAL)


def ganadorbob():
	##Se ponen las imagenes 
	vec_imagen=[PhotoImage(file="./gifbob/bob1.gif")]
	vec_imagen.append(PhotoImage(file="./gifbob/bob2.gif"))
	vec_imagen.append(PhotoImage(file="./gifbob/bob3.gif"))
	vec_imagen.append(PhotoImage(file="./gifbob/bob4.gif"))
	vec_imagen.append(PhotoImage(file="./gifbob/bob5.gif"))
	vec_imagen.append(PhotoImage(file="./gifbob/bob6.gif"))
	vec_imagen.append(PhotoImage(file="./gifbob/bob7.gif"))

	##Aqui se coloca la duracion en la que pasara cada imagen y cuantas imagenes se
	for i in range(0,7):
		imagen.config(image=vec_imagen[i])
		ven.update()
		sleep(.1)
	imagen.config(image=et7)
	ven.update()

def ganadorpatricio():
	##Se ponen las imagenes
	vec_imagen=[PhotoImage(file="./gifpatricio/pat1.gif")]
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat2.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat3.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat4.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat5.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat6.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat7.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat8.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat9.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat10.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat11.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat12.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat13.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat14.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat15.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat16.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat17.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat18.gif"))
	vec_imagen.append(PhotoImage(file="./gifpatricio/pat19.gif"))

	##Aqui se coloca la duracion en la que pasara cada imagen
	for i in range(0,19):
		imagen.config(image=vec_imagen[i])
		ven.update()
		sleep(.1)
	imagen.config(image=et7)
	ven.update()

def gifempate():
	##Se ponen las imagenes
	vec_imagen=[PhotoImage(file="./gifempate/e1.gif")]
	vec_imagen.append(PhotoImage(file="./gifempate/e2.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e3.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e4.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e5.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e6.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e7.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e8.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e9.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e10.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e11.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e12.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e13.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e14.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e15.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e16.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e17.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e18.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e19.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e20.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e21.gif"))
	vec_imagen.append(PhotoImage(file="./gifempate/e22.gif"))

	##Aqui se coloca la duracion en la que pasara cada imagen
	for i in range(0,22):
		imagen.config(image=vec_imagen[i])
		ven.update()
		sleep(.1)
	imagen.config(image=et7)
	ven.update()

##Se crean los combobox
cursor.execute('select Nom_usuario from usuarios')
lista=[]
combo1=ttk.Combobox(ven, font='Helvetica 12 bold', width=10)
combo1.place(x=95, y = 345)
combo2=ttk.Combobox(ven, font='Helvetica 12 bold', width=10)
combo2.place(x=120, y = 380)
for row in cursor:
 lista.append(row)
cursor.close()
conn.close()
combo1['values']=lista
combo2['values']=lista
combo1.bind("<<ComboboxSelected>>",combx)
combo2.bind("<<ComboboxSelected>>",combx1)



##Se colocan las etiquetas para el turno
etiqueta1=Label(ven,text="Turno DE:",bg="alice blue",font="timesnewroman 10 bold")
etiqueta1.place(x=135,y=310)
etiqueta2=Label(ven,bg="alice blue",font="timesnewroman 10 bold",width=6,textvariable=turno)
etiqueta2.place(x=199,y=310)
##Se colocan las etiquetas para que aparezca cuantas veces gano bob
etiqueta3=Label(ven,text="Bob=",bg="alice blue",font="timesnewroman 10 bold")
etiqueta3.place(x=20,y=345)
etiqueta4=Label(ven,bg="alice blue",font="timesnewroman 10 bold",width=3,textvariable=contador)
etiqueta4.place(x=55,y=345)
##Se coloca las etiquetas para que aparezca cuantas veces gano patricio
etiqueta5=Label(ven,text="Patricio=",bg="alice blue",font="timesnewroman 10 bold")
etiqueta5.place(x=20,y=380)
etiqueta6=Label(ven,bg="alice blue",font="timesnewroman 10 bold",width=3,textvariable=contador2)
etiqueta6.place(x=80,y=380)

##Se colocan los botones 
boton1=Button(ven,bg="light cyan",state=DISABLED,command=posicion1,image=fondo,textvariable=p1)
boton1.place(x=20, y=30)
boton2=Button(ven,bg="light cyan",state=DISABLED,command=posicion2,image=fondo,textvariable=p2)
boton2.place(x=125,y=30)
boton3=Button(ven,bg="light cyan",state=DISABLED,command=posicion3,image=fondo,textvariable=p3)
boton3.place(x=230,y=30)
boton4=Button(ven,bg="light cyan",state=DISABLED,command=posicion4,image=fondo,textvariable=p4)
boton4.place(x=20,y=123)
boton5=Button(ven,bg="light cyan",state=DISABLED,command=posicion5,image=fondo,textvariable=p5)
boton5.place(x=125,y=123)
boton6=Button(ven,bg="light cyan",state=DISABLED,command=posicion6,image=fondo,textvariable=p6)
boton6.place(x=230,y=123)
boton7=Button(ven,bg="light cyan",state=DISABLED,command=posicion7,image=fondo,textvariable=p7)
boton7.place(x=20,y=220)
boton8=Button(ven,bg="light cyan",state=DISABLED,command=posicion8,image=fondo,textvariable=p8)
boton8.place(x=125,y=220)
boton9=Button(ven,bg="light cyan",state=DISABLED,command=posicion9,image=fondo,textvariable=p9)
boton9.place(x=230,y=220)
##Se pone el boton de reiniciar
boton10=Button(ven,bg="medium orchid",image=medusa,command=reiniciar,state=DISABLED)
boton10.place(x=380,y=40)
##Se coloca el boton de continuar
boton11=Button(ven,bg="medium orchid",image=gary,command=reiniciar_marc,state=DISABLED)
boton11.place(x=380,y=150)
## creacion de boton para una nueva ventana
boton12=Button(ven,bg="blue",image=nueva, command=NuevaVentana)
boton12.place(x=380,y=260)

## creacion de un etiqueta para impresion de un gif
imagen=Label(ven,image=et7)
imagen.place(x=1,y=1)

ven.mainloop()